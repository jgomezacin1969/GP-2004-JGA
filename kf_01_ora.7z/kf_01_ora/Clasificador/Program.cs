﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

class Program
{
    static async Task Main(string[] args)
    {
        // Definir la URL del servicio
        string url = "http://127.0.0.1:5000/clasificar";

        // Crear los datos a enviar en el cuerpo de la solicitud (en formato JSON)
        var data = new
        {
            NUMERO_SOLICITUD = "12345",
            TEXTO_A_CLASIFICAR = "Este es el texto que será clasificado"
        };

        // Convertir el objeto a JSON
        string jsonData = JsonConvert.SerializeObject(data);

        // Crear un HttpClient para realizar la solicitud
        using (HttpClient client = new HttpClient())
        {
            // Crear el contenido de la solicitud, incluyendo los datos JSON y el tipo de contenido
            StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            // Realizar la solicitud POST
            HttpResponseMessage response = await client.PostAsync(url, content);

            // Leer la respuesta
            string result = await response.Content.ReadAsStringAsync();

            // Imprimir la respuesta en la consola
            Console.WriteLine(result);
        }
    }
}
