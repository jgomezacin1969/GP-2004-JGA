﻿using System.Configuration;
using Confluent.Kafka;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Empiezo");
        IniciarConsumer();
    }

    static void IniciarConsumer()
    {
        var cola = ConfigurationManager.AppSettings.Get("reg_consu_cola");
        var config = new ConsumerConfig
        {
            GroupId = "reg_workers",
            BootstrapServers = ConfigurationManager.AppSettings.Get("kafkaServer"),
            AutoOffsetReset = AutoOffsetReset.Earliest
        };

        using (var consumer = new ConsumerBuilder<Ignore, string>(config).Build())
        {
            var producerConfig = new ProducerConfig
            {
                BootstrapServers = ConfigurationManager.AppSettings.Get("kafkaServer")
            };
            var producer = new ProducerBuilder<Null, string>(producerConfig).Build();

            consumer.Subscribe(cola);
            Console.WriteLine("CONSUMER:" + cola);

            try
            {
                while (true)
                {
                    var mensaje = consumer.Consume();
                    if (!mensaje.Message.Value.Contains("procesado"))
                    {
                        Console.WriteLine("[[[ COLA : " + cola + " ]]]");
                        Console.WriteLine(mensaje.Message.Value);
                        Console.WriteLine("APLICAMOS ALGORITMOS AI");

                        // Agregar la etiqueta de mensaje procesado
                        var mensajeEnriquecido = mensaje.Message.Value + " - procesado";
                        Console.WriteLine("Publicamos por mismo topic datos enriquecidos o publicamos por nuevo topic");

                        // Publicar el mensaje enriquecido
                        producer.Produce(cola, new Message<Null, string> { Value = mensajeEnriquecido }, handler);
                    }
                    else
                    {
                        Console.WriteLine("Mensaje ya procesado, no se vuelve a consumir.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        static void handler(DeliveryReport<Null, string> report)
        {
            Console.WriteLine($"Mensaje enviado a Kafka: Cola: {report.Topic} - Mensaje {report.Value} - Estado: {report.Status}");
        }
    }
}
