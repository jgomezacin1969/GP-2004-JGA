﻿using System;
using System.Configuration;
using Confluent.Kafka;
using Oracle.ManagedDataAccess.Client;

class Program
{
    static void Main(string[] args)
    {
        var config = new ConsumerConfig
        {
            GroupId = "ms-sincro-group",
            BootstrapServers = "localhost:9099",
            AutoOffsetReset = AutoOffsetReset.Earliest
        };
        const String cola_valores = "valores";
        TestDB();
        using (var consumer = new ConsumerBuilder<Ignore, string>(config).Build())
        {
            consumer.Subscribe(cola_valores);
            Console.WriteLine("Escuchando la cola:" + cola_valores);

            try
            {
                while (true)
                {
                    var consumeResult = consumer.Consume();
                    Console.WriteLine($"Mensaje recibido: {consumeResult.Message.Value}");

                    // Procesa el mensaje e inserta en Oracle
                    InsertarMensajeEnOracle(consumeResult.Message.Value);
                    TestDB();
                }
            }
            catch (ConsumeException e)
            {
                Console.WriteLine($"Error al consumir: {e.Error.Reason}");
            }
        }
    }

    static void InsertarMensajeEnOracle(string mensaje)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleDbConnection"].ConnectionString;

        using (OracleConnection conn = new OracleConnection(connectionString))
        {
            conn.Open();

            using (OracleCommand cmd = new OracleCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "INSERT INTO kafka_mensajes (mensaje, fecha_recepcion) VALUES (:mensaje, SYSDATE)";
                cmd.Parameters.Add(new OracleParameter("mensaje", mensaje));

                try
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Mensaje insertado en Oracle");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error al insertar en Oracle: {ex.Message}");
                }
            }
        }
    }
    static void TestDB()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleDbConnection"].ConnectionString;

        using (OracleConnection conn = new OracleConnection(connectionString))
        {
            conn.Open();
            Console.WriteLine("Conectado a la BBDD");
            using (OracleCommand cmd = new OracleCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "SELECT COUNT(*) FROM kafka_mensajes";
                int registros = Convert.ToInt32(cmd.ExecuteScalar());

                cmd.CommandText = "SELECT COUNT(*) FROM kafka_mensajes WHERE PROCESADO IS NULL";
                int noproc = Convert.ToInt32(cmd.ExecuteScalar());

                using (OracleDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("Acceso como C##KAFKA --> MENSAJES. REGISTROS: " +  registros + ". PENDIENTES PROC:"+noproc);
                }
            }

        }
    }

}
