﻿using System;
using System.Configuration;
using System.Data;
using Confluent.Kafka;
using Oracle.ManagedDataAccess.Client;

class Program
{
    static Int64 nMensa = 0;
    static void Main(string[] args)
    {
        var producerConfig = new ProducerConfig
        {
            BootstrapServers = ConfigurationManager.AppSettings.Get("kafkaServer")
        };
        var cola = ConfigurationManager.AppSettings.Get("trb_produ_cola");

        using (var producer = new ProducerBuilder<Null, string>(producerConfig).Build())
        {
            while (true)
            {
                var mensajes = ObtenerMensajesDeOracle();

                foreach (var mensaje in mensajes)
                {
                    try
                    {
                        // Publicar el mensaje en la cola Kafka
                        producer.Produce(cola, new Message<Null, string> { Value = mensaje.contenido }, handler);

                        // Actualizar el estado de publicado a 'S'
                        ActualizarEstadoPublicado(mensaje.id);
                    }
                    catch (ProduceException<Null, string> e)
                    {
                        Console.WriteLine($"Error al publicar en Kafka: {e.Error.Reason}");
                    }
                }

                // Espera antes de volver a leer la base de datos
                System.Threading.Thread.Sleep(60000); // Espera 1 minuto
            }
        }
    }

    static void handler(DeliveryReport<Null, string> report)
    {
        Console.WriteLine($"Mensaje {nMensa++} enviado a Kafka: Cola: {report.Topic} - Mensaje {report.Value} - Estado: {report.Status}");
    }

    static List<(int id, string contenido)> ObtenerMensajesDeOracle()
    {
        var mensajes = new List<(int id, string contenido)>();

        string connectionString = ConfigurationManager.ConnectionStrings["OracleDbConnection"].ConnectionString;

        using (OracleConnection conn = new OracleConnection(connectionString))
        {
            conn.Open();

            using (OracleCommand cmd = new OracleCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "SELECT id, mensaje FROM kafka_mensajes WHERE procesado = 'S' ";
                using (OracleDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        mensajes.Add((reader.GetInt32(0), reader.GetString(1)));
                    }
                }
            }
        }

        return mensajes;
    }

    static void ActualizarEstadoPublicado(int id)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleDbConnection"].ConnectionString;

        using (OracleConnection conn = new OracleConnection(connectionString))
        {
            conn.Open();

            using (OracleCommand cmd = new OracleCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE kafka_mensajes SET publicado = 'S' WHERE id = :id";
                cmd.Parameters.Add(new OracleParameter("id", id));

                try
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine($"Mensaje con ID {id} marcado como publicado");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error al actualizar el estado de publicado: {ex.Message}");
                }
            }
        }
    }
}
